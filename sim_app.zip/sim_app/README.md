# SIM — Security Incident Mapping

A mini web application built for **SEN 202 (Weekend 1 Dev)** at Adekunle Ajasin University.
SIM lets students, staff, and residents report campus security incidents, and
visualizes those reports as a live dashboard and map.

## Problem

Campus security incidents (theft, assault, vandalism, harassment, etc.) frequently go
unreported to campus security or student affairs. This creates a gap between what's
actually happening on campus and what the official record shows — see the
[Ishikawa root-cause analysis](docs/SIM_Ishikawa.drawio) for the full breakdown.

Real questionnaire data collected for this project supports this: of 3 recorded
incidents (all theft, all at Hostel or Lecture Hall), **2 out of 3 were never reported**
to campus security.

## Features

- **Report form** — students/staff can log an incident in under two minutes, with
  optional anonymity (name and matric number are not required).
- **Dashboard** — live stats: total reports, % unreported, most common incident type,
  most affected location, plus a full incident table.
- **Map view** — incidents plotted on an illustrative campus zone map, showing where
  reports are clustering.

## Tech stack

- **Backend:** Flask (Python)
- **Storage:** JSON file (`data/incidents.json`) — no database required, per project scope
- **Frontend:** Server-rendered HTML/CSS (no JS framework), vanilla JS for minor interactivity

## Project structure

```
sim_app/
├── app.py                 # Flask application and routes
├── seed_data.py            # Converts the raw Google Form CSV export into data/incidents.json
├── requirements.txt
├── data/
│   └── incidents.json      # Incident records (JSON "database")
├── data_raw/
│   └── SSIM record .csv    # Original Google Form response export
└── templates/
    ├── base.html
    ├── index.html
    ├── report.html
    ├── thanks.html
    ├── dashboard.html
    └── map.html
```

## Running locally

```bash
pip install -r requirements.txt
python app.py
```

Then visit `http://127.0.0.1:5000` in your browser.

## Routes

| Route | Description |
|---|---|
| `/` | Landing page |
| `/report` | Incident report form (GET/POST) |
| `/dashboard` | Stats and full incident table |
| `/map` | Visual map of incident locations |
| `/api/incidents` | Raw JSON data (for debugging / future integration) |

## Data source

Seed data (`data/incidents.json`) is generated from real responses collected via the
project's Google Form questionnaire (see `data_raw/`). New reports submitted through
the web app are appended to the same JSON file.

## Related documentation

- Google Form questionnaire design
- Ishikawa (fishbone) root-cause diagram — `docs/SIM_Ishikawa.drawio`
- SRS (Software Requirements Specification)
- Use-case diagram(s)

## Author

SEN 202 — Weekend 1 Dev submission, Adekunle Ajasin University.
