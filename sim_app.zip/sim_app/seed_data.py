import csv
import json
import uuid

# Approximate campus zone coordinates (relative map, not real GPS —
# since AAUA lat/long per-building isn't available, we use a simple
# illustrative campus layout grid for the map view).
LOCATION_COORDS = {
    "Hostel": {"x": 25, "y": 65},
    "Lecture hall": {"x": 55, "y": 30},
    "Cafeteria": {"x": 70, "y": 55},
    "Car Park": {"x": 40, "y": 80},
    "Fence/Perimeter": {"x": 10, "y": 20},
    "Other": {"x": 50, "y": 50},
}

def get_coords(location, other_note):
    base = LOCATION_COORDS.get(location, LOCATION_COORDS["Other"]).copy()
    # add slight jitter so overlapping reports at same location are visible
    return base

records = []
with open("data_raw/SSIM record .csv") as f:
    reader = csv.DictReader(f)
    for row in reader:
        location = row["7 . Location of  Campus ."].strip()
        other = row['7b .If "Other" specify location .'].strip()
        coords = get_coords(location, other)
        records.append({
            "id": str(uuid.uuid4())[:8],
            "full_name": row["1 . Full name "].strip(),
            "matric_no": row["2. . Matriculation Number."].strip(),
            "department": row["3 . Department /Faulty ."].strip(),
            "incident_type": row["4 . Type of Incident ."].strip(),
            "incident_date": row["5 .Date of Incident ."].strip(),
            "incident_time": row["6 .Time of Incident."].strip(),
            "location": location,
            "location_other": other,
            "description": row["8 .Brief description of Incident."].strip(),
            "reported": row["9 .Was the incident reported to security or student affairs."].strip(),
            "evidence_url": row["10 . Update Evidence."].strip(),
            "timestamp": row["Timestamp"].strip(),
            "map_x": coords["x"],
            "map_y": coords["y"],
        })

with open("data/incidents.json", "w") as f:
    json.dump(records, f, indent=2)

print(f"Wrote {len(records)} records")
for r in records:
    print(r["incident_type"], r["location"], r["reported"])
